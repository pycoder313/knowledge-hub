import axios from "axios";
import crypto from "crypto";

const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY as string;
const PAYSTACK_BASE_URL = "https://api.paystack.co";

export const SUBSCRIPTION_AMOUNT_NAIRA = 1000;
export const SUBSCRIPTION_AMOUNT_KOBO = SUBSCRIPTION_AMOUNT_NAIRA * 100;

const paystackClient = axios.create({
  baseURL: PAYSTACK_BASE_URL,
  headers: {
    Authorization: `Bearer ${PAYSTACK_SECRET_KEY}`,
    "Content-Type": "application/json",
  },
});

export async function initializePaystackTransaction(email: string, reference: string) {
  const response = await paystackClient.post("/transaction/initialize", {
    email,
    amount: SUBSCRIPTION_AMOUNT_KOBO,
    reference,
    callback_url: `${process.env.APP_URL}/payment/verify`,
  });
  return response.data as {
    status: boolean;
    message: string;
    data: { authorization_url: string; access_code: string; reference: string };
  };
}

export async function verifyPaystackTransaction(reference: string) {
  const response = await paystackClient.get(`/transaction/verify/${reference}`);
  return response.data as {
    status: boolean;
    data: { status: string; reference: string; amount: number; customer: { email: string } };
  };
}

// Validates the X-Paystack-Signature header on incoming webhooks.
export function isValidPaystackSignature(rawBody: string, signature: string | null): boolean {
  if (!signature) return false;
  const hash = crypto
    .createHmac("sha512", PAYSTACK_SECRET_KEY)
    .update(rawBody)
    .digest("hex");
  return hash === signature;
}
