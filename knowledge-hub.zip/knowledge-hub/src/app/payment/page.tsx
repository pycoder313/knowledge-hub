"use client";

import { useState } from "react";
import axios from "axios";

export default function PaymentPage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handlePay() {
    setError(null);
    setLoading(true);
    try {
      const { data } = await axios.post("/api/payment/initialize");
      window.location.href = data.authorizationUrl;
    } catch {
      setError("Could not start payment. Please try again.");
      setLoading(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-6 py-16">
      <div className="w-full max-w-sm rounded-2xl border border-gold/30 bg-surface p-8 text-center">
        <p className="font-mono text-xs uppercase tracking-widest text-teal">One step left</p>
        <p className="mt-4 font-display text-5xl text-gold">₦1,000</p>
        <p className="mt-1 text-sm text-muted">Unlocks every course and e-book for 30 days</p>

        {error && <p className="mt-4 text-sm text-red-400">{error}</p>}

        <button
          onClick={handlePay}
          disabled={loading}
          className="mt-8 w-full rounded-full bg-gold py-3 font-medium text-ink transition hover:bg-gold/90 disabled:opacity-60"
        >
          {loading ? "Redirecting to Paystack…" : "Pay ₦1,000 with Paystack"}
        </button>

        <p className="mt-4 text-xs text-muted">
          You'll be taken to Paystack's secure checkout to complete payment.
        </p>
      </div>
    </main>
  );
}
