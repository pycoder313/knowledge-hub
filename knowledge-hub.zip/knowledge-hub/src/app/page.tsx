import Link from "next/link";

const CATEGORIES = [
  "Programming", "AI", "Cybersecurity", "Forex", "Crypto",
  "Graphics Design", "Digital Marketing", "UI/UX", "Freelancing", "Islamic Knowledge",
];

const FEATURES = [
  { title: "Unlimited courses", body: "Every course on the shelf, from the first lesson to the certificate, unlocked the moment your slip goes active." },
  { title: "Unlimited e-books", body: "Read online or download the PDF. Bookmark a page and pick up exactly where you stopped." },
  { title: "One flat price", body: "No per-course fees, no upsells. ₦1,000 covers everything on the platform for 30 days." },
  { title: "Certificates included", body: "Finish a course and get a certificate with a QR code an employer can verify in seconds." },
];

const FAQS = [
  { q: "What exactly does ₦1,000 get me?", a: "Full access to every course and e-book on Knowledge Hub for 30 days — no per-item charges." },
  { q: "What happens after 30 days?", a: "Your slip expires automatically. Renew any time with one tap to pick up right where you left off." },
  { q: "Which payment methods work?", a: "Card, bank transfer, and USSD, processed through Paystack, Flutterwave, or Monnify." },
  { q: "Can I preview a course before paying?", a: "Yes — every course opens with a free 5-minute preview and every e-book with 5 free pages." },
];

export default function LandingPage() {
  return (
    <main className="min-h-screen">
      {/* NAV */}
      <header className="sticky top-0 z-40 border-b border-white/5 bg-ink/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <span className="font-display text-xl tracking-tight">Knowledge Hub</span>
          <nav className="hidden gap-8 text-sm text-muted md:flex">
            <a href="#library" className="hover:text-paper">Library</a>
            <a href="#pricing" className="hover:text-paper">Pricing</a>
            <a href="#faq" className="hover:text-paper">FAQ</a>
          </nav>
          <div className="flex gap-3">
            <Link href="/login" className="rounded-full px-4 py-2 text-sm text-muted hover:text-paper">
              Log in
            </Link>
            <Link
              href="/register"
              className="rounded-full bg-gold px-4 py-2 text-sm font-medium text-ink hover:bg-gold/90"
            >
              Get access
            </Link>
          </div>
        </div>
      </header>

      {/* HERO */}
      <section className="mx-auto grid max-w-6xl items-center gap-16 px-6 py-20 md:grid-cols-2 md:py-28">
        <div>
          <p className="mb-5 font-mono text-xs uppercase tracking-[0.2em] text-teal">
            One slip. Thirty days. Everything.
          </p>
          <h1 className="font-display text-4xl leading-[1.1] md:text-5xl">
            Every course and e-book on the shelf, for the price of{" "}
            <span className="italic text-gold">lunch</span>.
          </h1>
          <p className="mt-6 max-w-md text-muted">
            Programming, AI, forex, design, freelancing, and more — sixteen
            categories, one subscription. Pay once, learn without limits for
            30 days.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <Link
              href="/register"
              className="rounded-full bg-gold px-7 py-3 font-medium text-ink transition hover:bg-gold/90"
            >
              Subscribe for ₦1,000
            </Link>
            <a
              href="#library"
              className="rounded-full border border-white/15 px-7 py-3 text-paper transition hover:border-white/30"
            >
              Browse the library
            </a>
          </div>
        </div>

        {/* SIGNATURE ELEMENT: the subscription slip */}
        <div className="relative mx-auto w-full max-w-sm rotate-[2deg] rounded-2xl bg-paper text-ink shadow-2xl shadow-black/40">
          <div className="p-7">
            <div className="flex items-start justify-between">
              <div>
                <p className="font-mono text-[11px] uppercase tracking-widest text-ink/50">
                  Subscription Slip
                </p>
                <p className="mt-1 font-display text-lg">Knowledge Hub</p>
              </div>
              <span className="rounded-full border border-teal/40 bg-teal/10 px-3 py-1 font-mono text-[10px] uppercase tracking-widest text-teal">
                Active
              </span>
            </div>

            <div className="my-6 flex items-baseline gap-2 border-y border-dashed border-ink/15 py-5">
              <span className="font-display text-4xl">₦1,000</span>
              <span className="font-mono text-xs text-ink/50">/ 30 days</span>
            </div>

            <dl className="space-y-2 font-mono text-xs text-ink/60">
              <div className="flex justify-between">
                <dt>Ref</dt>
                <dd>KH-7F2A91C0</dd>
              </div>
              <div className="flex justify-between">
                <dt>Access</dt>
                <dd>Unlimited courses + e-books</dd>
              </div>
              <div className="flex justify-between">
                <dt>Certificate</dt>
                <dd>Included</dd>
              </div>
            </dl>
          </div>

          {/* perforation */}
          <div className="relative h-0">
            <div className="absolute -left-3 top-0 h-6 w-6 -translate-y-1/2 rounded-full bg-ink" />
            <div className="absolute -right-3 top-0 h-6 w-6 -translate-y-1/2 rounded-full bg-ink" />
            <div className="mx-6 border-t-2 border-dashed border-ink/10" />
          </div>

          <div className="px-7 pb-6 pt-4 text-center font-mono text-[10px] uppercase tracking-widest text-ink/40">
            Keep this slip. It renews the moment it expires.
          </div>
        </div>
      </section>

      {/* CATEGORIES */}
      <section id="library" className="border-y border-white/5 bg-surface/40 py-16">
        <div className="mx-auto max-w-6xl px-6">
          <p className="mb-6 font-mono text-xs uppercase tracking-[0.2em] text-teal">
            The shelf
          </p>
          <div className="flex flex-wrap gap-3">
            {CATEGORIES.map((c) => (
              <span
                key={c}
                className="rounded-full border border-white/10 bg-surface px-4 py-2 text-sm text-muted"
              >
                {c}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="mx-auto max-w-6xl px-6 py-20">
        <h2 className="font-display text-3xl">What's inside the slip</h2>
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {FEATURES.map((f) => (
            <div key={f.title} className="rounded-2xl border border-white/10 bg-surface p-7">
              <h3 className="font-display text-xl text-gold">{f.title}</h3>
              <p className="mt-2 text-sm text-muted">{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" className="border-y border-white/5 bg-surface/40 py-20">
        <div className="mx-auto max-w-md px-6 text-center">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-teal">Pricing</p>
          <h2 className="mt-3 font-display text-3xl">Just one plan</h2>
          <div className="mt-8 rounded-2xl border border-gold/30 bg-surface p-8">
            <p className="font-display text-5xl text-gold">₦1,000</p>
            <p className="mt-1 text-sm text-muted">per 30 days</p>
            <ul className="mt-6 space-y-2 text-left text-sm text-muted">
              <li>— Unlimited courses</li>
              <li>— Unlimited e-books</li>
              <li>— Downloads &amp; certificates</li>
              <li>— Priority support</li>
            </ul>
            <Link
              href="/register"
              className="mt-7 block rounded-full bg-gold py-3 font-medium text-ink hover:bg-gold/90"
            >
              Subscribe now
            </Link>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="mx-auto max-w-3xl px-6 py-20">
        <h2 className="font-display text-3xl">Questions</h2>
        <div className="mt-8 divide-y divide-white/10">
          {FAQS.map((f) => (
            <details key={f.q} className="group py-5">
              <summary className="flex cursor-pointer list-none items-center justify-between font-medium">
                {f.q}
                <span className="text-muted group-open:rotate-45">+</span>
              </summary>
              <p className="mt-3 text-sm text-muted">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      <footer className="border-t border-white/5 py-10 text-center text-xs text-muted">
        © {new Date().getFullYear()} Knowledge Hub. Built for learners across Nigeria.
      </footer>
    </main>
  );
}
