import Link from "next/link";

export default function ForgotPasswordPage() {
  return (
    <main className="flex min-h-screen items-center justify-center px-6 py-16">
      <div className="w-full max-w-sm text-center">
        <h1 className="font-display text-2xl">Password reset</h1>
        <p className="mt-3 text-sm text-muted">
          This flow isn't wired up yet in this build — it's on the list in the
          README under "What's next."
        </p>
        <Link href="/login" className="mt-6 inline-block text-teal hover:underline">
          Back to login
        </Link>
      </div>
    </main>
  );
}
