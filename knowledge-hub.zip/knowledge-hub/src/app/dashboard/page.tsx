import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { verifyAuthToken, AUTH_COOKIE_NAME } from "@/lib/auth";

async function getActiveSubscription(userId: string) {
  const subscription = await prisma.subscription.findFirst({
    where: { userId, status: "ACTIVE", endDate: { gt: new Date() } },
    orderBy: { endDate: "desc" },
  });
  return subscription;
}

export default async function DashboardPage() {
  const token = cookies().get(AUTH_COOKIE_NAME)?.value;
  const payload = token ? verifyAuthToken(token) : null;

  if (!payload) {
    redirect("/login?redirect=/dashboard");
  }

  const user = await prisma.user.findUnique({ where: { id: payload!.userId } });
  if (!user) {
    redirect("/login");
  }

  const subscription = await getActiveSubscription(user!.id);
  if (!subscription) {
    redirect("/payment");
  }

  const daysRemaining = Math.max(
    0,
    Math.ceil((subscription.endDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24))
  );

  return (
    <main className="mx-auto max-w-5xl px-6 py-14">
      <p className="font-mono text-xs uppercase tracking-widest text-teal">Dashboard</p>
      <h1 className="mt-2 font-display text-3xl">Welcome back, {user!.fullName.split(" ")[0]}</h1>

      <div className="mt-8 grid gap-6 md:grid-cols-3">
        <div className="rounded-2xl border border-white/10 bg-surface p-6">
          <p className="text-sm text-muted">Subscription</p>
          <p className="mt-2 font-display text-2xl text-teal">Active</p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-surface p-6">
          <p className="text-sm text-muted">Days remaining</p>
          <p className="mt-2 font-display text-2xl text-gold">{daysRemaining}</p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-surface p-6">
          <p className="text-sm text-muted">Renews on</p>
          <p className="mt-2 font-display text-2xl">
            {subscription.endDate.toLocaleDateString("en-NG", { day: "numeric", month: "short", year: "numeric" })}
          </p>
        </div>
      </div>

      <div className="mt-10 rounded-2xl border border-white/10 bg-surface p-6">
        <h2 className="font-display text-xl">Continue learning</h2>
        <p className="mt-2 text-sm text-muted">
          Your courses and e-books will appear here once the catalog is connected.
        </p>
      </div>
    </main>
  );
}
