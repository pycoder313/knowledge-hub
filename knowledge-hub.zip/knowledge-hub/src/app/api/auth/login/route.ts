import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { verifyPassword, signAuthToken, AUTH_COOKIE_NAME, authCookieOptions } from "@/lib/auth";

const loginSchema = z.object({
  email: z.string().email("Enter a valid email address"),
  password: z.string().min(1, "Password is required"),
});

// Generic message so we never reveal whether the email exists.
const INVALID_CREDENTIALS = "Incorrect email or password";

export async function POST(request: NextRequest) {
  const body = await request.json();
  const parsed = loginSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0].message },
      { status: 400 }
    );
  }

  const { email, password } = parsed.data;

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) {
    return NextResponse.json({ error: INVALID_CREDENTIALS }, { status: 401 });
  }

  const validPassword = await verifyPassword(password, user.passwordHash);
  if (!validPassword) {
    return NextResponse.json({ error: INVALID_CREDENTIALS }, { status: 401 });
  }

  const token = signAuthToken({ userId: user.id, email: user.email });

  const response = NextResponse.json({
    user: { id: user.id, fullName: user.fullName, email: user.email },
  });
  response.cookies.set(AUTH_COOKIE_NAME, token, authCookieOptions);
  return response;
}
