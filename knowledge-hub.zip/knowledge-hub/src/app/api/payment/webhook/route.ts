import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { isValidPaystackSignature } from "@/lib/paystack";

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

export async function POST(request: NextRequest) {
  const rawBody = await request.text();
  const signature = request.headers.get("x-paystack-signature");

  if (!isValidPaystackSignature(rawBody, signature)) {
    return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  }

  const event = JSON.parse(rawBody);

  if (event.event === "charge.success") {
    const { reference, status } = event.data;

    const payment = await prisma.payment.findUnique({ where: { reference } });
    if (!payment) {
      return NextResponse.json({ error: "Unknown payment reference" }, { status: 404 });
    }

    // Idempotency guard: webhooks can be delivered more than once.
    if (payment.status === "SUCCESS") {
      return NextResponse.json({ received: true });
    }

    await prisma.payment.update({
      where: { reference },
      data: { status: status === "success" ? "SUCCESS" : "FAILED" },
    });

    if (status === "success") {
      const now = new Date();
      await prisma.subscription.create({
        data: {
          userId: payment.userId,
          status: "ACTIVE",
          startDate: now,
          endDate: new Date(now.getTime() + THIRTY_DAYS_MS),
        },
      });
    }
  }

  return NextResponse.json({ received: true });
}
