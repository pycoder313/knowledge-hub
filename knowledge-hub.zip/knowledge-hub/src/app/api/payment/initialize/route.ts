import { NextRequest, NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { prisma } from "@/lib/prisma";
import { verifyAuthToken, AUTH_COOKIE_NAME } from "@/lib/auth";
import { initializePaystackTransaction, SUBSCRIPTION_AMOUNT_NAIRA } from "@/lib/paystack";

export async function POST(request: NextRequest) {
  const token = request.cookies.get(AUTH_COOKIE_NAME)?.value;
  const payload = token ? verifyAuthToken(token) : null;

  if (!payload) {
    return NextResponse.json({ error: "You must be logged in" }, { status: 401 });
  }

  const user = await prisma.user.findUnique({ where: { id: payload.userId } });
  if (!user) {
    return NextResponse.json({ error: "Account not found" }, { status: 404 });
  }

  const reference = `KH-${randomUUID()}`;

  await prisma.payment.create({
    data: {
      userId: user.id,
      reference,
      amount: SUBSCRIPTION_AMOUNT_NAIRA,
      provider: "PAYSTACK",
      status: "PENDING",
    },
  });

  try {
    const paystackResponse = await initializePaystackTransaction(user.email, reference);
    return NextResponse.json({
      authorizationUrl: paystackResponse.data.authorization_url,
      reference,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Could not start payment. Please try again." },
      { status: 502 }
    );
  }
}
