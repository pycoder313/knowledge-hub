import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0E1130",
        surface: "#171A3D",
        surfaceHover: "#1E2149",
        gold: "#E8B84B",
        teal: "#2BB3A3",
        paper: "#F4F2EC",
        muted: "#9497B8",
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "serif"],
        body: ["var(--font-inter)", "sans-serif"],
        mono: ["var(--font-jetbrains)", "monospace"],
      },
      backgroundImage: {
        "grain": "radial-gradient(circle at 1px 1px, rgba(244,242,236,0.04) 1px, transparent 0)",
      },
    },
  },
  plugins: [],
};
export default config;
