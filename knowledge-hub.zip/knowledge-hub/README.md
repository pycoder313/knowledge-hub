# Knowledge Hub

Landing page → register → login → pay ₦1,000 via Paystack → subscription
activates → dashboard. This is the **first slice** of the full platform
described in the original spec (courses, e-books, admin panel, etc. are not
built yet — see "What's next" below).

## What's included in this slice

- **Landing page** (`/`) — hero, category shelf, features, pricing, FAQ.
  Distinctive dark-indigo / gold / teal theme with a "subscription slip"
  as the signature visual (perforated payment-receipt card).
- **Auth** — register (`/register`) and login (`/login`) with bcrypt password
  hashing, JWT stored in an HttpOnly cookie, and a logout route.
- **Payment** (`/payment`) — starts a Paystack transaction for exactly ₦1,000
  and redirects to Paystack's hosted checkout.
- **Webhook** (`/api/payment/webhook`) — verifies Paystack's signature,
  marks the payment successful, and creates a 30-day active subscription.
- **Dashboard** (`/dashboard`) — server-rendered, redirects to `/payment` if
  the user has no active subscription; shows days remaining.
- **Database** — Prisma schema for `User`, `Subscription`, `Payment`.

## Setup

```bash
npm install
cp .env.example .env   # then fill in real values
npx prisma migrate dev --name init
npm run dev
```

You'll need:

1. A PostgreSQL database (Railway, Supabase, Neon, or local Postgres all work)
   — put its connection string in `DATABASE_URL`.
2. A Paystack account in **test mode** — copy the secret key from
   Settings → API Keys & Webhooks into `PAYSTACK_SECRET_KEY`.
3. In the Paystack dashboard, set the webhook URL to
   `https://<your-deployed-domain>/api/payment/webhook` (Paystack requires a
   public HTTPS URL — use a tool like `ngrok` for local testing).

## How the payment flow works

1. `/api/payment/initialize` creates a `Payment` row with status `PENDING`
   and asks Paystack for a checkout URL for ₦1,000 (amount is fixed in
   `src/lib/paystack.ts`, not taken from the client, so it can't be tampered
   with).
2. The user pays on Paystack's hosted page.
3. Paystack calls `/api/payment/webhook`. The handler verifies the
   `x-paystack-signature` header, marks the payment `SUCCESS`, and creates a
   `Subscription` valid for 30 days from that moment.
4. `/dashboard` checks for an active, non-expired subscription on every load
   and redirects to `/payment` if there isn't one.

## What's next (from the original spec, not yet built)

- Course & e-book modules (upload, playback, reading, progress, reviews)
- Admin panel (manage users, content, payments, coupons, analytics)
- Email verification, password reset, real email/SMS notifications
- Flutterwave / Monnify as alternate payment providers
- Search, categories as real filterable data, certificates with QR codes
- Rate limiting, CSRF protection, audit logs
- Tests and CI/CD

Happy to build any of these next — the auth, payment, and subscription
foundations here are meant to be extended, not replaced.
